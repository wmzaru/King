<?php
/**
* Players they`ve ever been registered there, asiign variables
*/
include("counter/usersever.php");
$smarty -> assign(array("Usersever" => $ilosc));

?>
