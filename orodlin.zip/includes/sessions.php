<?php 
session_start(); 
?>