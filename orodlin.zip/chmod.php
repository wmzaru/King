<?php
chmod('/cache', 0777);
chmod('/templates_c', 0777);
chmod('/images/sigs/cache', 0777);
chmod('/avatars', 0777);
chmod('/images/tribes', 0777);
chmod('/images/screens/', 0777);
chmod('/Orodlin/adodb', 0777);
chmod('/includes', 0777);
chmod('/includes/main', 0777);
chmod('ourlogs.txt', 0777);
chmod('/counter/d_licznik.php', 0777);
chmod('/counter/licznik.php', 0777);
chmod('/counter/record.php', 0777);
chmod('/counter/usersever.php', 0777);

echo "DONE";

?>