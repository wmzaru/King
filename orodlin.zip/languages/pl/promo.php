<?php
define('PROMO_TITLE', 'Promocja gry');
define('PROMO_TEXT', '<p>Bardzo ważna dla Orodlinu jest promocja gry, w której Wy także możecie wziąć udział (a właściwie to tylko Wy możecie to zrobić). Poprzez wklejenie którejś z poniższych grafik na swoją stronę internetową bądź forum pomagacie nam, zachęcając nowych graczy do przyłączenia się i wspólnego grania. Za wszelkią pomoc w promowaniu Orodlinu serdecznie dziękujemy.</p>'); 
define('TOPLISTA', 'Zagłosuj na nas! W ten sposób promujesz grę i pomagasz nam się rozwijać.');
?>
