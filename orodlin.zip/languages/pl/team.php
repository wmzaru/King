<?php

define ('TEAM_LIST', 'Oto lista ludzi, którzy poświęcając swój wolny czas, zarywając noce, zaniedbując rodzinę i dom pracują, by gra ta stawała się jak najlepsza. Doceńmy ich.');
define ('TEAM_INVALID_MEMBER_DATA', 'Nieprawidłowe dane członka teamu');
define ('TEAM_NO_MEMBERS', 'Nie ma aktualnie członków Team Orodlin.');
define ('TEAM_NAME', 'Nick');
define ('TEAM_GAMEID', 'ID w grze');
define ('TEAM_FUNCTION', 'Odpowiedzialny za');
define ('TEAM_CONTACT', 'Kontakt');

define ('TEAM_ADD', 'Dodaj członka');
define ('TEAM_MODIFY', 'Edytuj dane');
define ('TEAM_DELETE', 'Usuń');

define ('TEAM_ADD_SUCCESS', 'Członek teamu dodany pomyślnie! <a href="team.php?int=1">Odśwież</a>');
define ('TEAM_MODIFY_SUCCESS', 'Modyfikacja przeprowadzona pomyślnie! <a href="team.php?int=1">Odśwież</a>');
define ('TEAM_DELETE_SUCCESS', 'Usunięcie przebiegło pomyślnie! <a href="team.php?int=1">Odśwież</a>');

define ('DONT_FUCK_WITH_ME', 'Czego tu szukasz?');
define ('TEAM_DELETE_CONFIRMATION', 'Na pewno chcesz usunąć tego członka Team Orodlin');
define ('BACK', 'Wróć');
?>
