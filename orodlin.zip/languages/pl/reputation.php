<?php
define('T_REPUTATION_DESC', 'Tutaj znajduje się lista wszystkich zasłużonych Orodlinowi. Bla Bla bla...');
define('T_POINTS', 'punktów');
define('SHOW_LIST', 'Pokaż listę zasług');
define('T_LIST_BACK', 'Wróć do listy zasłużonych');
define('T_PROFILE_BACK', 'Wróć do profilu');
define('PLAYER_REPUTATION', 'Tutaj znajduje się lista wszystkich przyznanych punktów reputacji wraz z opisem zasług.');
define('T_DONATORS_LINK', 'Wesprzeć Orodlin możesz także poprzez dobrowolną dotację pieniężną. Wszyscy, którzy to uczynią, odnotowani zostają dla potomnych w alei zasłużonych. Możesz teraz do niej przejść.');
define('T_ALLEY', 'Aleja zasłużonych');
define('T_ADDED', 'Przyznano');
define('T_FOR_A', 'za');
?>