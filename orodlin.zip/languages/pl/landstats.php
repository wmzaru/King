<?php
/**
 *   File functions:
 *   Polish language for land stats
 */

//$Id$

define('ERROR', 'Zapomnij o tym!');
$arrDesc = array('wybraną płeć', 'wybraną rasę', 'wybraną klasę', 'wybrane bóstwo');
$arrTableNames = array('Płeć', 'Rasa', 'Klasa', 'Bóstwo');
define('LPOPULATION', 'Liczba graczy:');
define('LDISTRIBUTION', 'Podział społeczeństwa ze względu na:');
define('LCOUNTER', 'Lp.');
define('LAMOUNT', 'Liczba graczy');
define('LPERCENTAGE', 'Procent populacji');
define('LNEXT', 'Następna aktualizacja statystyk około godziny ');
?>
