
<?php

define ('BACK', 'Wróć do strony głównej.');
define ('MSG_403', 'Nie masz uprawnień do przeglądania tej strony.');
define ('MSG_404', 'Nie ma takiej strony/pliku.');
define ('UNKNOWN', 'Wystąpił nieznany błąd.');

?>
