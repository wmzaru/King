<?php
define ('AGE', 'Wiek');
define ('LEVEL', 'Poziom');
define ('SIGN_INVALID_PARAMS_NOTIFY', 'Podaj poprawnie parametry ID oraz TYPE w adresie!');

define ('SIGN_VALID_PARAMS_EXAMPLE', 'Konwencja: sign.php?id=x&type=y, gdzie x - Twój ID, y - typ tła (od 1 do 3).');
define ('STH', 'Ekipa Orodlin pozdrawia. :)');
?>
